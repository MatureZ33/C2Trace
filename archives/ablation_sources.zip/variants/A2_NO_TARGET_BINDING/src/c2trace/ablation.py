"""A2-No-Target-Binding treatment adapter."""
from __future__ import annotations

from typing import Any

from c2trace.agents.auditor import AuditorAgent
from c2trace.execution import PreparedToolCall
from c2trace.models import AuditDecision, AuditVerdict, CaseFile, StrategyNode
from c2trace.tools import RESPONSE_TOOLS


VARIANT_ID = "A2-NO-TARGET-BINDING"


class NoTargetBindingAuditor(AuditorAgent):
    """Keep authorization/replay protection but omit target identity binding."""

    def audit(
        self,
        case: CaseFile,
        node: StrategyNode,
        resolved_args: dict[str, Any] | PreparedToolCall,
    ) -> AuditDecision:
        prepared = (
            resolved_args
            if isinstance(resolved_args, PreparedToolCall)
            else PreparedToolCall.create(
                node_id=node.node_id,
                tool=node.tool,
                arguments=resolved_args,
            )
        )
        args = prepared.arguments
        if node.tool not in RESPONSE_TOOLS:
            raise PermissionError("A2 target-binding adapter received a non-response node")
        if node.tool == "kill_process" and not (args.get("pid") or args.get("process_name")):
            return self._reject(case, node, "kill_process requires PID or process_name")
        if node.tool == "remove_file" and not str(args.get("file_path") or "").strip():
            return self._reject(case, node, "remove_file requires file_path")

        decision = AuditDecision(
            node_id=node.node_id,
            verdict=AuditVerdict.APPROVED,
            reason="A2 ablation: target identity binding omitted",
        )
        case.add_audit_decision(decision)
        authorization = self.authorization_issuer.issue(
            case_id=case.case_id,
            decision=decision,
            call=prepared,
            target_lock={"lock_id": f"ablation-no-target-{decision.decision_id}"},
        )
        self._authorizations[decision.decision_id] = authorization
        decision.authorization_receipt = authorization.public_receipt()
        return decision

    @staticmethod
    def _reject(case: CaseFile, node: StrategyNode, reason: str) -> AuditDecision:
        decision = AuditDecision(
            node_id=node.node_id,
            verdict=AuditVerdict.REJECTED,
            reason=reason,
        )
        case.add_audit_decision(decision)
        return decision


def build_variant_auditor(*, require_llm: bool = False) -> AuditorAgent:
    return NoTargetBindingAuditor(require_llm=require_llm)
