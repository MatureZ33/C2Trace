"""A1-No-Auditor treatment adapter.

This module is only used by the A1 ablation copy.  The frozen root C2Trace
package is not modified.  The external protected-object boundary remains
active; this variant removes the independent C2Trace audit decision only.
"""
from __future__ import annotations

from typing import Any

from c2trace.agents.auditor import AuditorAgent
from c2trace.execution import PreparedToolCall
from c2trace.models import AuditDecision, AuditVerdict, CaseFile, StrategyNode


VARIANT_ID = "A1-NO-AUDITOR"


class NoAuditor(AuditorAgent):
    """Approve the prepared action without Auditor hard rules or LLM review."""

    def audit(
        self,
        case: CaseFile,
        node: StrategyNode,
        resolved_args: dict[str, Any] | PreparedToolCall,
    ) -> AuditDecision:
        prepared = (
            resolved_args
            if isinstance(resolved_args, PreparedToolCall)
            else PreparedToolCall.create(
                node_id=node.node_id,
                tool=node.tool,
                arguments=resolved_args,
            )
        )
        target_lock = None
        if self.target_validator is not None:
            target_lock = self.target_validator.lock_response(
                case, node, prepared.arguments
            )
        decision = AuditDecision(
            node_id=node.node_id,
            verdict=AuditVerdict.APPROVED,
            reason="A1 ablation: independent Auditor decision removed",
        )
        case.add_audit_decision(decision)
        authorization = self.authorization_issuer.issue(
            case_id=case.case_id,
            decision=decision,
            call=prepared,
            target_lock=target_lock or {"lock_id": f"ablation-{decision.decision_id}"},
        )
        self._authorizations[decision.decision_id] = authorization
        decision.authorization_receipt = authorization.public_receipt()
        return decision


def build_variant_auditor(*, require_llm: bool = False) -> AuditorAgent:
    return NoAuditor(require_llm=require_llm)
