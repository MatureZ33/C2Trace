"""Case compatibility validation for the RQ3 ablation runners.

The shared Bench v4 validator intentionally rejects the legacy AURORA public
tool benchmark schema.  This adapter keeps that strict validator for every
canonical case and admits AURORA only after checking an explicit, immutable
compatibility receipt and the runtime loader/deployment manifest.
"""

from __future__ import annotations

from pathlib import Path
from typing import Any, Mapping

from c2trace.bench_v4.controller_support import read_json, sha256_file
from c2trace.bench_v4.runtime import (
    BenchV4RuntimeError,
    discover_case_paths,
    load_runtime_case,
    verify_deployment_manifest,
)


AURORA_CASE_ID = "AURORA-CHAIN-002"
ABLATION_CASE_IDS = (
    "AURORA-CHAIN-001",
    "AURORA-CHAIN-002",
    "AEL-WIZARD-EMOTET-001",
    "AEL-MUSTANG-PANDA-PLUGX-001",
    "AEL-CARBANAK-RAT-001",
    "AEL-OILRIG-SIDETWIST-001",
    "AEL-SANDWORM-EXARAMEL-WIN-001",
    "MEP-WINDOWS-WEBSHELL-01",
)
LEGACY_CASE_IDS = set(ABLATION_CASE_IDS) - {AURORA_CASE_ID}
PARENT_PROTOCOL_SHA256 = (
    "ad77e704c8300a7a6676ed12226a0afbd39e1c177595ea8f3a697cd04f6f9e79"
)
EXPECTED_IDENTITY = {
    "source_kind": "aurora",
    "dataset_stratum": "public_tool_benchmark",
    "source_id": "aurora-demo-chain-002-20260731",
}


def _receipt_path(project_root: Path) -> Path:
    return (
        project_root
        / "消融C2Trace"
        / "case_compatibility"
        / "AURORA-CHAIN-002_compatibility_receipt.json"
    )


def _legacy_receipt_path(project_root: Path) -> Path:
    return (
        project_root
        / "消融C2Trace"
        / "case_compatibility"
        / "ablation_v1_legacy_case_assets_receipt.json"
    )


def validate_aurora_compatibility(
    bench_root: str | Path, project_root: str | Path
) -> tuple[Any, Any, dict[str, Any]]:
    """Validate AURORA runtime assets without weakening canonical validation."""

    bench = Path(bench_root).resolve()
    project = Path(project_root).resolve()
    receipt = read_json(_receipt_path(project))
    if receipt.get("case_id") != AURORA_CASE_ID:
        raise BenchV4RuntimeError("AURORA compatibility receipt case_id mismatch")
    if receipt.get("parent_protocol_sha256") != PARENT_PROTOCOL_SHA256:
        raise BenchV4RuntimeError("AURORA compatibility receipt parent protocol drifted")
    for field in (
        "case_assets_are_unchanged",
        "ground_truth_is_unchanged",
        "scorer_is_unchanged",
        "model_input_is_unchanged",
    ):
        if receipt.get(field) is not True:
            raise BenchV4RuntimeError(f"AURORA compatibility receipt lacks {field}")

    case_root = bench / "aurora" / "cases" / AURORA_CASE_ID
    runtime = load_runtime_case(bench, case_root / "case.json")
    deployment = verify_deployment_manifest(runtime)
    source = runtime.case.get("source")
    source = source if isinstance(source, Mapping) else {}
    observed = {
        "source_kind": runtime.case.get("source_kind"),
        "dataset_stratum": runtime.case.get("dataset_stratum"),
        "source_id": source.get("source_id"),
    }
    if observed != EXPECTED_IDENTITY:
        raise BenchV4RuntimeError(f"AURORA legacy case identity drifted: {observed!r}")

    raw_hashes = receipt.get("raw_asset_hashes")
    if not isinstance(raw_hashes, Mapping):
        raise BenchV4RuntimeError("AURORA compatibility receipt has no raw_asset_hashes")
    for relative, expected in raw_hashes.items():
        path = case_root / str(relative)
        if not path.is_file() or sha256_file(path).casefold() != str(expected).casefold():
            raise BenchV4RuntimeError(f"AURORA compatibility asset hash drifted: {path}")

    lock_info = receipt.get("canonical_source_lock")
    if not isinstance(lock_info, Mapping):
        raise BenchV4RuntimeError("AURORA canonical source lock is missing")
    lock_path = project / str(lock_info.get("path") or "")
    if not lock_path.is_file() or sha256_file(lock_path).casefold() != str(
        lock_info.get("sha256") or ""
    ).casefold():
        raise BenchV4RuntimeError("AURORA canonical source lock is missing or drifted")
    locked = read_json(lock_path)
    artifact_path = str(lock_info.get("artifact_path") or "")
    rows = [
        row
        for row in locked.get("files", [])
        if isinstance(row, Mapping) and row.get("path") == artifact_path
    ]
    if len(rows) != 1 or str(rows[0].get("sha256") or "").casefold() != str(
        lock_info.get("artifact_sha256") or ""
    ).casefold():
        raise BenchV4RuntimeError("AURORA canonical source artifact lock is inconsistent")

    legacy = receipt.get("legacy_metadata_reconciliation")
    if not isinstance(legacy, Mapping) or str(source.get("artifact_sha256") or "") != str(
        legacy.get("raw_case_source_artifact_sha256") or ""
    ):
        raise BenchV4RuntimeError("AURORA legacy source hash reconciliation is incomplete")
    return runtime, deployment, receipt


def validate_legacy_case(
    case_id: str, bench_root: str | Path, project_root: str | Path
) -> tuple[Any, Any, dict[str, Any]]:
    """Validate one protocol-registered legacy case by immutable asset hashes."""

    if case_id not in LEGACY_CASE_IDS:
        raise BenchV4RuntimeError(f"case is not registered in the ablation protocol: {case_id}")
    bench = Path(bench_root).resolve()
    project = Path(project_root).resolve()
    receipt = read_json(_legacy_receipt_path(project))
    if receipt.get("parent_protocol_sha256") != PARENT_PROTOCOL_SHA256:
        raise BenchV4RuntimeError("legacy case compatibility receipt parent protocol drifted")
    for field in (
        "case_assets_are_unchanged",
        "ground_truth_is_unchanged",
        "scorer_is_unchanged",
        "model_input_is_unchanged",
    ):
        if receipt.get(field) is not True:
            raise BenchV4RuntimeError(f"legacy case compatibility receipt lacks {field}")
    expected = receipt.get("cases", {}).get(case_id)
    if not isinstance(expected, Mapping):
        raise BenchV4RuntimeError(f"legacy case compatibility entry is missing: {case_id}")
    paths = discover_case_paths(bench, case_id=case_id)
    if len(paths) != 1:
        raise BenchV4RuntimeError(f"expected one runtime case for {case_id}, found {len(paths)}")
    case_path = paths[0]
    runtime = load_runtime_case(bench, case_path)
    deployment = verify_deployment_manifest(runtime)
    contracts = runtime.case.get("contracts")
    if not isinstance(contracts, Mapping):
        raise BenchV4RuntimeError(f"{case_id} has no contracts object")
    assets: dict[str, Path] = {"case.json": case_path}
    for field in (
        "mapping",
        "ground_truth",
        "target_profile",
        "operation_plan",
        "evidence_plan",
        "cleanup_plan",
    ):
        assets[Path(str(contracts[field])).name] = (bench / str(contracts[field])).resolve()
    assets["caldera/deployment_manifest.json"] = (
        bench / str(contracts["caldera_bundle"])
    ).resolve()
    for name, expected_hash in expected.items():
        path = assets.get(str(name))
        if path is None or not path.is_file() or sha256_file(path).casefold() != str(expected_hash).casefold():
            raise BenchV4RuntimeError(f"legacy case asset hash drifted: {case_id}/{name}")
    return runtime, deployment, receipt


def require_ablation_compatible_bench(
    bench_root: str | Path,
    *,
    project_root: str | Path,
    case_ids: set[str] | None,
) -> dict[str, Any]:
    """Validate only protocol-registered legacy cases through locked profiles."""

    selected = set(case_ids or ())
    if not selected:
        selected = set(ABLATION_CASE_IDS)
    aurora_ids = {case_id for case_id in selected if case_id == AURORA_CASE_ID}
    canonical_ids = selected - aurora_ids
    errors: list[str] = []
    warnings: list[str] = []
    counts: dict[str, Any] = {
        "schemas": 0,
        "sources": 0,
        "cases": 0,
        "admissions": 0,
        "errors": 0,
        "warnings": 0,
    }
    compatibility_cases: list[dict[str, Any]] = []
    for case_id in sorted(canonical_ids):
        try:
            _runtime, deployment, receipt = validate_legacy_case(
                case_id, bench_root, project_root
            )
            compatibility_cases.append(
                {
                    "case_id": case_id,
                    "profile": receipt.get("profile"),
                    "deployment_manifest_sha256": deployment.manifest_sha256,
                    "status": "validated_by_explicit_legacy_case_profile",
                }
            )
        except BenchV4RuntimeError as exc:
            errors.append(str(exc))

    if aurora_ids:
        _runtime, deployment, receipt = validate_aurora_compatibility(
            bench_root, project_root
        )
        compatibility_cases.append(
            {
                "case_id": AURORA_CASE_ID,
                "profile": receipt.get("compatibility_profile"),
                "deployment_manifest_sha256": deployment.manifest_sha256,
                "status": "validated_by_explicit_aurora_compatibility_profile",
            }
        )
    if errors:
        raise BenchV4RuntimeError(
            "ablation case compatibility validation failed: " + " | ".join(errors)
        )
    counts["cases"] = int(counts.get("cases", 0)) + len(compatibility_cases)
    return {
        "schema_version": "c2trace.ablation.validation.v1",
        "valid": not errors,
        "counts": counts,
        "errors": errors,
        "warnings": warnings,
        "compatibility_cases": compatibility_cases,
    }
