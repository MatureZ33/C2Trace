# C2Trace Bench v3 scorer contract

The scorer consumes two UTF-8 JSON objects and never consults CALDERA output at
scoring time.

## Ground Truth

The canonical shape is:

```json
{
  "schema_version": "c2trace.bench.ground_truth.v3",
  "case_id": "AF-MAAS-WIN-01",
  "ability_instances": [
    {
      "instance_key": "scenario.run_key",
      "operation_id": "scenario-operation-id",
      "link_id": "link-id",
      "ability_id": "ability-id",
      "attack_mapped": true,
      "mandatory": true,
      "executed": true,
      "metric_eligible": true,
      "trace_facts": [
        {
          "trace_id": "globally-unique-trace-id",
          "trace_type": "process",
          "canonical_key": "stable-human-readable-key",
          "required": true,
          "discriminative": true,
          "anchor": true,
          "shared_context": false,
          "scoreable_by_c2trace": true,
          "observable_by": ["c2trace"],
          "valid_window": "after_scenario_before_response",
          "producer_ability_instance": "scenario-operation-id:link-id:ability-id",
          "expected_value": {
            "pid": 4242,
            "path": "C:\\Users\\Public\\c2t_run.exe"
          },
          "source_evidence": "evidence/before_response.json#/target"
        }
      ]
    }
  ],
  "expected": {
    "response": [
      {
        "tool": "kill_process",
        "required": true,
        "arguments": {"pid": 4242}
      }
    ]
  }
}
```

`instance_key` is the canonical v3 identifier; `ability_instance_id` and
`instance_id` remain accepted for compatibility.  An ability enters the
Trace-Producing Ability Ratio denominator when `attack_mapped`, `mandatory`, and
`executed` are all true.  It enters the Ability Recall denominator only when
`metric_eligible` is also true and it has at least one supported trace with
`scoreable_by_c2trace: true`.  A template value of `executed: null` is treated as
false; the live finalizer must write an explicit boolean after validating its
CALDERA link.  Metric-ineligible abilities remain visible in per-ability output
but cannot add TP or FN.  Unsupported trace types and traces explicitly marked
`scoreable_by_c2trace: false` (legacy `scoreable: false` is also accepted) are
not scored.  Scoreable trace IDs must be globally unique.

`valid_window` is a semantic evidence phase, not an inferred wall-clock range.
The controller enforces it by requiring a validated `before_response` snapshot
after both CALDERA Operations and by proving the same evidence is unchanged after
the C2Trace dry-run.  The scorer therefore matches only the materialized facts
that passed those phase gates; it does not invent timestamps for findings that
represent live host state.

Supported trace types are `network_connection`, `process`,
`process_parent_edge`, `file`, `registry_run_key`, `scheduled_task`, `service`,
`powershell_history`, and `dns_cache`.

## CaseFile

The second input is the unmodified C2Trace `casefile.json`.  The scorer reads
`findings` for trace evaluation and successful, non-dry-run `action_results` for
response-action evaluation. Failed actions and dry-run proposals remain missing
required response actions rather than being credited as TP. It ignores the seed alert, summaries, response/cleanup findings,
and unlinked `persistence_candidate` findings.  Aliases are merged before
matching; matching is deterministic, global, and one-to-one.  Thus one
observation, including a `shared_context` observation, can credit at most one
Ground Truth trace and one ability.

Windows paths, registry paths, task paths, process/service names, domains, and
hexadecimal hashes are compared case-insensitively after deterministic
normalization.  An expected value may specify only the fields needed to identify
the trace; every specified field must match.  Empty metric denominators are
serialized as JSON `null` and rendered as `N/A`.

## Command line

```powershell
.\.venv\Scripts\python.exe .\scripts\score_c2trace_bench_v3.py `
  --ground-truth .\ground_truth.json `
  --casefile .\casefile.json `
  --output-dir .\evaluation
```

The command writes `score.json` and `score.md`.  Ability Precision is always
reported as `N/A`; C2Trace does not independently predict CALDERA ability IDs.
Ability-level reporting therefore uses Any-Trace Recall, mean trace coverage,
and Strict Recall, while atomic traces and response actions use Precision,
Recall, and F1.

## Formal-batch aggregation

The aggregate interface accepts either score objects or the trial wrappers in
the controller's `batch_context.json`:

```json
{
  "case_id": "AF-MAAS-WIN-01",
  "trial_id": "AF-MAAS-WIN-01-r01",
  "trial_class": "evaluation_valid_pass",
  "score": {"schema_version": "c2trace.bench.evaluation.v2"},
  "operational_metrics": {
    "wrong_target": false,
    "manx_network_absent": true,
    "manx_process_absent": true,
    "manx_file_absent": true,
    "manx_run_key_absent": true,
    "control_sandcat_alive": true,
    "end_to_end_duration_ms": 12000,
    "investigation_duration_ms": 7000,
    "response_duration_ms": 3000,
    "verification_duration_ms": 2000,
    "llm_calls": 4,
    "tool_calls": 9,
    "prompt_tokens": 2000,
    "completion_tokens": 800,
    "total_tokens": 2800
  }
}
```

Operational fields are optional. Missing values remain `null`/`N/A`; they are
never replaced with zero. Infrastructure-invalid attempts remain in trial-class
counts but are excluded from all effect metric denominators.

```powershell
.\.venv\Scripts\python.exe .\scripts\aggregate_c2trace_bench_v3.py `
  --batch-context .\results\c2trace_bench_v3\<batch_id>\batch_context.json `
  --output-dir .\results\c2trace_bench_v3\<batch_id>\aggregate `
  --bootstrap-samples 10000 `
  --seed 20260714
```

The report contains per-scene trial macro and micro results, overall macro by
trial and by scene, and overall micro results recomputed from pooled TP/FP/FN and
ability hit/denominator counts. Numeric distributions include median, Q1, Q3,
IQR, and a deterministic percentile-bootstrap 95% interval for the arithmetic
mean. The implementation uses only the Python standard library.
