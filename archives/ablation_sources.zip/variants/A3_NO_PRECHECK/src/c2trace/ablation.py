"""A3-No-Precheck variant marker and factory."""
from __future__ import annotations

from c2trace.agents.auditor import AuditorAgent


VARIANT_ID = "A3-NO-PRECHECK"


def build_variant_auditor(*, require_llm: bool = False) -> AuditorAgent:
    # Auditor and target binding remain present.  The variant removes only
    # the dry-run/identity check between preparation and execution.
    return AuditorAgent(require_llm=require_llm)
