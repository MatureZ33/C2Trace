"""A4-No-PostVerify variant marker and factory."""
from __future__ import annotations

from c2trace.agents.auditor import AuditorAgent


VARIANT_ID = "A4-NO-POSTVERIFY"


def build_variant_auditor(*, require_llm: bool = False) -> AuditorAgent:
    # All pre-response controls remain present.  Verify nodes are skipped by
    # the variant WorkflowController implementation.
    return AuditorAgent(require_llm=require_llm)
